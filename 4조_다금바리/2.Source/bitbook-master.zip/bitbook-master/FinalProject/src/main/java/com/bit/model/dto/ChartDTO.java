package com.bit.model.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ChartDTO {
	//userHistory table
	private String loginStatus_Monthly;
	private int Jan;
	private int Feb;
	private int Mar;
	private int Apr;
	private int May;
	private int Jun;
}
