//package com.bit.controller.admin;
/*
 * package com.bit.controller.chat;
 * 
 * import org.springframework.stereotype.Controller; import
 * org.springframework.web.bind.annotation.GetMapping;
 * 
 * @Controller public class AdminController {
 * 
 * @GetMapping("/chatView") public String chatView() { return
 * "common/chat/chatView"; }
 * 
 * 챗뷰->프론트 다 합쳐벌인것,,구별해서 쓰기로 수정해서 얘도 주석
 * }
 */