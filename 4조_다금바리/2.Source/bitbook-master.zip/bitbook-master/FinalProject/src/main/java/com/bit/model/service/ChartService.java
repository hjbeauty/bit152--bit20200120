package com.bit.model.service;

import java.util.List;

import com.bit.model.dto.ChartDTO;



public interface ChartService {
	public List<ChartDTO> getLoginDate();

}
