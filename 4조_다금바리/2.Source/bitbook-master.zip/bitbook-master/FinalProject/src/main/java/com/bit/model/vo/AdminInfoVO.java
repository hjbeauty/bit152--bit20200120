package com.bit.model.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AdminInfoVO {
	private int adminCode;
	private String adminId;
	private String adminPw;
	
}
