package com.bit.model.dao;

public interface UserDAO {

}
