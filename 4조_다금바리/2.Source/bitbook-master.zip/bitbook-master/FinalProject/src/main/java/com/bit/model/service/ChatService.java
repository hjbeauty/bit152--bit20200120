package com.bit.model.service;

import java.util.List;

import com.bit.model.vo.ChattingVO;

public interface ChatService {
	public List<ChattingVO> getChatting();
}
