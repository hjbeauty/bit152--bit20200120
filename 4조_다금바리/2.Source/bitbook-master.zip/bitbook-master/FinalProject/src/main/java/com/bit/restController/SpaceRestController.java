package com.bit.restController;

public class SpaceRestController {

}
