	$(function(){
		getModalFormEditPage("editPage-popup-link");
	})